package com.halo.profileui;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Activity_Main extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
